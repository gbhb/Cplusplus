/*****************************************
* Exercise 2
* Name: �f�ɿ�
* Student Number: 107502558
* Course: 2018-CE1001
******************************************/
#include<iostream>


using namespace std;


int main(){
int i,j; //i=�Q���� j=����
for(i=1;i<10;i++){
        for(j=1;j<10;j++){
        cout<<i<<"*"<<j<<"="<<i*j<<"\t";
        }
        cout<<"\n";
}
        	return 0;}
